# 回测指标计算模块
import numpy as np
import pandas as pd

def calc_metrics(balance_df, trades_df, init_cash=100000, period='day'):
	"""
	计算累计收益率、年化收益率、最大回撤、波动率、胜率、盈亏比等
	period: 'day'（日线）或'min'（分钟线）
	"""
	result = {}
	balance_df = balance_df.copy()
	balance_df['ret'] = balance_df['total'].pct_change().fillna(0)
	# 累计收益率
	result['累计收益率'] = (balance_df['total'].iloc[-1] / init_cash) - 1
	# 年化参数
	if period == 'day':
		annual_factor = 252
	elif period == 'min':
		# 假设A股4小时/天，242天/年，1天240分钟
		annual_factor = 242 * 240
	else:
		annual_factor = 252
	# 年化收益率
	n = len(balance_df)
	if n > 1:
		result['年化收益率'] = (1 + result['累计收益率']) ** (annual_factor / n) - 1
	else:
		result['年化收益率'] = np.nan
	# 最大回撤
	cummax = balance_df['total'].cummax()
	drawdown = (balance_df['total'] - cummax) / cummax
	result['最大回撤'] = drawdown.min()
	# 波动率
	result['年化波动率'] = balance_df['ret'].std() * np.sqrt(annual_factor)
	# 胜率、盈亏比
	if not trades_df.empty:
		profits = []
		for i in range(1, len(trades_df), 2):
			buy = trades_df.iloc[i-1]
			sell = trades_df.iloc[i]
			profit = (sell['price'] - buy['price']) * buy['qty']
			profits.append(profit)
		profits = np.array(profits)
		result['胜率'] = (profits > 0).sum() / len(profits) if len(profits) > 0 else np.nan
		result['盈亏比'] = profits[profits > 0].mean() / (-profits[profits < 0].mean()) if (profits > 0).any() and (profits < 0).any() else np.nan
	else:
		result['胜率'] = np.nan
		result['盈亏比'] = np.nan
	return result
