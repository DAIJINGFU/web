# 回测主引擎 (增强版)
import pandas as pd
from typing import Callable, Union, Dict, Any

class BacktestEngine:
	"""单标的简化回测引擎（增强）：
	支持：
	  1. 信号模式：策略返回 -1/0/1 代表 卖出/保持/买入（全仓）。
	  2. 目标仓位模式：策略可返回 dict，如 {"target_pos":0.5} 代表目标 50% 仓位。
	  3. 手续费：佣金 + 印花税；滑点：在成交价上加/减固定金额（或按比例）。
	  4. 价格模式：执行价使用行的 'close' 或 'open' （exec_price='close'/'open'）。
	  5. 允许部分仓位（基于 target_pos 或按信号全仓/清仓）。
	  6. 最大回撤/最大亏损强平（simple risk control）。
	保持对旧策略函数 (row, position)->signal 的兼容。
	"""

	def __init__(
		self,
		data: pd.DataFrame,
		strategy_func: Callable,
		init_cash: float = 100000,
		commission_rate: float = 0.0003,   # 双边佣金率（买卖都收）
		stamp_duty: float = 0.001,          # 卖出印花税
		slippage: float = 0.0,              # 每股滑点（绝对金额，简单模型）
		exec_price: str = 'close',          # 'close' 或 'open'
		max_drawdown_stop: float = None,    # 例如 0.3 表示回撤30%强平
		max_loss_stop: float = None         # 例如 0.4 表示累计亏损40%强平
	):
		self.data = data.copy().reset_index(drop=True)
		self.strategy_func = strategy_func
		self.init_cash = init_cash
		self.cash = init_cash
		self.position = 0  # 当前持股数量
		self.trades = []    # 记录交易
		self.daily_balance = []
		self.commission_rate = commission_rate
		self.stamp_duty = stamp_duty
		self.slippage = slippage
		self.exec_price = exec_price
		self.max_drawdown_stop = max_drawdown_stop
		self.max_loss_stop = max_loss_stop
		# 内部跟踪
		self._peak_equity = init_cash
		self._stopped = False

	def _get_price(self, row: pd.Series) -> float:
		price = row[self.exec_price] if self.exec_price in row else row['close']
		return float(price)

	def _apply_slippage(self, price: float, side: str) -> float:
		# side: 'buy' or 'sell'; 简单模型：买价+slippage，卖价-slippage
		if self.slippage <= 0:
			return price
		if side == 'buy':
			return price + self.slippage
		else:
			return price - self.slippage if price - self.slippage > 0 else price

	def _deal_commission(self, amount: float, side: str) -> float:
		# amount = 成交总额 = price * qty
		commission = amount * self.commission_rate
		tax = amount * self.stamp_duty if side == 'sell' else 0.0
		return commission + tax

	def _update_risk(self, equity: float):
		if equity > self._peak_equity:
			self._peak_equity = equity
		dd = 1 - equity / self._peak_equity  # 回撤比例
		loss_ratio = 1 - equity / self.init_cash
		if self.max_drawdown_stop is not None and dd >= self.max_drawdown_stop:
			self._stopped = True
		if self.max_loss_stop is not None and loss_ratio >= self.max_loss_stop:
			self._stopped = True

	def _parse_strategy_output(self, output: Union[int, Dict[str, Any]], current_price: float) -> float:
		"""将策略输出解析成目标仓位比例 (0~1)。
		兼容：
		  - int 信号：1=全仓，0=保持原仓位，-1=清仓
		  - dict： {'target_pos':0.3} 指定目标仓位 30%
		返回目标仓位比例。
		"""
		if isinstance(output, dict) and 'target_pos' in output:
			target = max(0.0, min(1.0, float(output['target_pos'])))
			return target
		if isinstance(output, (int, float)):
			sig = int(output)
			if sig > 0:
				return 1.0
			elif sig < 0:
				return 0.0
			else:
				# 保持当前仓位 => 用一个特殊值 -1 表示“不调整”
				return -1
		# 未知格式：不调整
		return -1

	def run(self):
		for i, row in self.data.iterrows():
			if self._stopped:
				# 已触发强平：保持现金，不再交易，但仍记录净值
				price = self._get_price(row)
				equity = self.cash + self.position * price
				self.daily_balance.append({
					'datetime': row['datetime'],
					'total': equity,
					'cash': self.cash,
					'position': self.position,
					'stopped': True
				})
				continue

			price_raw = self._get_price(row)
			# 调用策略
			output = self.strategy_func(row, self.position)
			target_ratio = self._parse_strategy_output(output, price_raw)

			# 计算当前权益
			equity_before = self.cash + self.position * price_raw

			# 如果策略要求调整仓位（目标仓位比例 >=0 表示需要解析）
			if target_ratio >= 0:
				# 使用“目标股数”法避免价值 -> 股数 floor 造成尾差残股
				portfolio_value = self.cash + self.position * price_raw
				target_qty_float = target_ratio * portfolio_value / price_raw
				# 加一个极小偏移避免 0.999999 -> 0 的截断影响
				target_qty = int(target_qty_float + 1e-8)
				if target_qty < 0:
					target_qty = 0
				qty_diff = target_qty - self.position  # >0 买入  <0 卖出
				# 防抖：目标差额占权益比例过小则忽略
				if abs(qty_diff) > 0:
					value_diff_est = abs(qty_diff) * price_raw
					if value_diff_est / (equity_before + 1e-12) <= 1e-4:
						qty_diff = 0
				if qty_diff > 0:
					# 买入 qty_diff 股
					side = 'buy'
					exec_price = self._apply_slippage(price_raw, side)
					qty = qty_diff
					cost = qty * exec_price
					fee = self._deal_commission(cost, side)
					total_cost = cost + fee
					if qty > 0 and total_cost <= self.cash:
						self.cash -= total_cost
						self.position += qty
						self.trades.append({
							'datetime': row['datetime'],
							'type': 'buy',
							'price': exec_price,
							'qty': qty,
							'fee': fee
						})
				elif qty_diff < 0:
					# 卖出 abs(qty_diff) 股
					side = 'sell'
					exec_price = self._apply_slippage(price_raw, side)
					qty = min(-qty_diff, self.position)
					if qty > 0:
						proceeds = qty * exec_price
						fee = self._deal_commission(proceeds, side)
						self.cash += proceeds - fee
						self.position -= qty
						self.trades.append({
							'datetime': row['datetime'],
							'type': 'sell',
							'price': exec_price,
							'qty': qty,
							'fee': fee
						})

			# 记录当期净值
			price_used = price_raw
			equity = self.cash + self.position * price_used
			self._update_risk(equity)
			self.daily_balance.append({
				'datetime': row['datetime'],
				'total': equity,
				'cash': self.cash,
				'position': self.position,
				'stopped': self._stopped
			})

		# 回测结束后如果仍有持仓，按最后价格平仓（不再滑点）
		if self.position > 0:
			last_row = self.data.iloc[-1]
			last_price = self._get_price(last_row)
			proceeds = self.position * last_price
			fee = self._deal_commission(proceeds, 'sell')
			self.cash += proceeds - fee
			self.trades.append({
				'datetime': last_row['datetime'],
				'type': 'sell',
				'price': last_price,
				'qty': self.position,
				'fee': fee,
				'final_close': True
			})
			self.position = 0
			final_equity = self.cash
			self.daily_balance.append({
				'datetime': last_row['datetime'],
				'total': final_equity,
				'cash': self.cash,
				'position': 0,
				'stopped': self._stopped
			})

		return pd.DataFrame(self.daily_balance), pd.DataFrame(self.trades)
