# 数据导入与预处理模块
import pandas as pd
import os

def load_csv(filepath):
	"""
	自动识别分钟线和日线csv格式，返回标准DataFrame和周期类型（'day'或'min'）。
	支持：
	1. 分钟线：datetime,open,close,high,low,volume,money
	2. 日线：date,open,high,low,close,volume,factor,amount
	"""
	if not os.path.exists(filepath):
		raise FileNotFoundError(f"文件不存在: {filepath}")
	df = pd.read_csv(filepath)
	# 标准化列名
	df.columns = [c.strip().lower() for c in df.columns]
	# 分钟线格式
	if set(['datetime','open','close','high','low','volume','money']).issubset(df.columns):
		df.rename(columns={'money': 'amount'}, inplace=True)
		df['datetime'] = pd.to_datetime(df['datetime'])
		# 统一顺序：datetime, open, high, low, close, volume, amount
		df = df[['datetime', 'open', 'high', 'low', 'close', 'volume', 'amount']]
		df = df.sort_values('datetime').reset_index(drop=True)
		period = 'min'
	# 日线格式
	elif set(['date','open','high','low','close','volume','factor','amount']).issubset(df.columns):
		df.rename(columns={'date': 'datetime'}, inplace=True)
		df['datetime'] = pd.to_datetime(df['datetime'])
		# 统一顺序：datetime, open, high, low, close, volume, amount
		df = df[['datetime', 'open', 'high', 'low', 'close', 'volume', 'amount']]
		df = df.sort_values('datetime').reset_index(drop=True)
		period = 'day'
	else:
		raise ValueError('不支持的csv格式，需包含标准字段')
	# 缺失值处理
	df = df.dropna()
	return df, period
