# 可视化模块
import matplotlib.pyplot as plt
import matplotlib
import pandas as pd

# 设置matplotlib全局字体为SimHei，支持中文
matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
matplotlib.rcParams['axes.unicode_minus'] = False

def plot_equity_curve(balance_df, title='资金曲线'):
	fig, ax = plt.subplots(figsize=(10, 5))
	ax.plot(balance_df['datetime'], balance_df['total'], label='总资产')
	ax.set_title(title)
	ax.set_xlabel('日期')
	ax.set_ylabel('资产（元）')
	ax.legend()
	ax.grid(True)
	fig.tight_layout()
	return fig

def plot_drawdown(balance_df, title='最大回撤'):
	cummax = balance_df['total'].cummax()
	drawdown = (balance_df['total'] - cummax) / cummax
	fig, ax = plt.subplots(figsize=(10, 3))
	ax.bar(balance_df['datetime'], drawdown, color='red')
	ax.set_title(title)
	ax.set_xlabel('日期')
	ax.set_ylabel('回撤比例')
	fig.tight_layout()
	return fig
