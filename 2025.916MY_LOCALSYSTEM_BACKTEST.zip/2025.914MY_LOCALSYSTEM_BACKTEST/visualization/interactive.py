"""交互式可视化 (Plotly)
提供：
- 资金曲线 + 同步悬停显示收益率
- 回撤曲线
- 买卖点标记（散点 + hover 显示数量与费用）
- 仓位占比副图（position * price / equity）
"""
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots


def prepare_drawdown(balance_df: pd.DataFrame):
    cummax = balance_df['total'].cummax()
    dd = (balance_df['total'] - cummax) / cummax
    return dd


def equity_figure(balance_df: pd.DataFrame, trades_df: pd.DataFrame=None, show_position=True):
    df = balance_df.copy()
    if 'equity' in df.columns:
        df['total'] = df['equity']
    dd = prepare_drawdown(df)

    rows = 3 if show_position else 2
    specs = [[{"secondary_y": False}]] * rows
    fig = make_subplots(rows=rows, cols=1, shared_xaxes=True, vertical_spacing=0.02)

    # 资金曲线
    fig.add_trace(go.Scatter(x=df['datetime'], y=df['total'], name='总资产', mode='lines', line=dict(color='#1f77b4')), row=1, col=1)

    # 回撤
    fig.add_trace(go.Bar(x=df['datetime'], y=dd, name='回撤', marker_color='crimson'), row=2, col=1)

    # 仓位副图
    if show_position:
        price_proxy = df['total'] / (df['cash'] + 1e-9)  # 不准确，只用于防止零除
        # 更准确仓位价值比例 = position*last_price / total
        if 'position' in df.columns:
            # 估算价格 = (total - cash)/position (当 position>0)
            est_price = (df['total'] - df['cash']).where(df['position']>0) / df['position'].where(df['position']>0)
            position_value = df['position'] * est_price.fillna(0)
            pos_ratio = position_value / df['total']
            fig.add_trace(go.Scatter(x=df['datetime'], y=pos_ratio, name='仓位比例', mode='lines', line=dict(color='#2ca02c')), row=3, col=1)

    # 买卖点
    if trades_df is not None and not trades_df.empty:
        buys = trades_df[trades_df['type']=='buy']
        sells = trades_df[trades_df['type']=='sell']
        if not buys.empty:
            fig.add_trace(go.Scatter(x=buys['datetime'], y=[None]*len(buys),
                                     mode='markers', marker_symbol='triangle-up',
                                     marker=dict(color='green', size=10),
                                     hovertext=[f"BUY<br>price:{p}<br>qty:{q}<br>fee:{f}" for p,q,f in zip(buys['price'], buys['qty'], buys.get('fee',[0]*len(buys)))],
                                     name='买入',
                                     hoverinfo='text'), row=1, col=1)
        if not sells.empty:
            fig.add_trace(go.Scatter(x=sells['datetime'], y=[None]*len(sells),
                                     mode='markers', marker_symbol='triangle-down',
                                     marker=dict(color='red', size=10),
                                     hovertext=[f"SELL<br>price:{p}<br>qty:{q}<br>fee:{f}" for p,q,f in zip(sells['price'], sells['qty'], sells.get('fee',[0]*len(sells)))],
                                     name='卖出',
                                     hoverinfo='text'), row=1, col=1)

    fig.update_layout(height=600 if show_position else 500, legend=dict(orientation='h'))
    fig.update_yaxes(title_text='资产', row=1, col=1)
    fig.update_yaxes(title_text='回撤', row=2, col=1)
    if show_position:
        fig.update_yaxes(title_text='仓位比例', row=3, col=1, range=[0,1])
    return fig


def trade_table(trades_df: pd.DataFrame):
    if trades_df is None or trades_df.empty:
        return None
    show_cols = [c for c in ['datetime','type','price','qty','fee','final_close'] if c in trades_df.columns]
    return trades_df[show_cols].copy()
