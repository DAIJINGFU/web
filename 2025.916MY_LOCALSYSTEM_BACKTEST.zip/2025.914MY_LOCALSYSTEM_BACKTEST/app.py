# Streamlit 网页入口
import streamlit as st
import pandas as pd
import sys
import importlib.util
import os
import streamlit as st
import pandas as pd
import importlib.util
import os
from backtest.data_loader import load_csv
from backtest.engine import BacktestEngine
from backtest.metrics import calc_metrics
from visualization.plot import plot_equity_curve, plot_drawdown
try:
	from visualization.interactive import equity_figure
	PLOTLY_AVAILABLE = True
except Exception:
	PLOTLY_AVAILABLE = False

st.set_page_config(page_title='本地回测系统', layout='wide')

st.title('本地回测系统')
st.caption('上传行情 → 选择策略 → 参数 → 回测。交互图表支持鼠标悬停。')

with st.sidebar:
	uploaded_file = st.file_uploader('上传行情 CSV', type=['csv'])
	hist_window = st.slider('历史窗口长度', min_value=20, max_value=500, value=200, step=10)
	show_position = st.checkbox('显示仓位副图', value=True)
	show_trades = st.checkbox('显示买卖点', value=True)
	st.markdown('---')
	st.caption('策略与回测参数')
	strategy_files = [f for f in os.listdir('strategies') if f.endswith('.py')]
	strategy_name = st.selectbox('选择策略文件', strategy_files) if uploaded_file else None
	init_cash = st.number_input('初始资金', value=100000, step=10000)
	commission_rate = st.number_input('佣金率', value=0.0003, format='%f')
	stamp_duty = st.number_input('印花税(卖出)', value=0.001, format='%f')
	slippage = st.number_input('滑点(元/股)', value=0.0, format='%f')
	exec_price = st.selectbox('成交价', ['close','open'])
	drawdown_stop = st.number_input('最大回撤停止(0=关闭)', value=0.0, format='%f')
	loss_stop = st.number_input('最大亏损停止(0=关闭)', value=0.0, format='%f')
	run_btn = st.button('开始回测', type='primary', use_container_width=True)

def load_strategy(strategy_path: str):
	spec = importlib.util.spec_from_file_location('user_strategy', strategy_path)
	module = importlib.util.module_from_spec(spec)
	spec.loader.exec_module(module)
	func = None
	for attr in dir(module):
		if attr.endswith('strategy'):
			func = getattr(module, attr)
			break
	return func, module

@st.cache_data(show_spinner=False)
def cache_csv(file_bytes) -> pd.DataFrame:
	return pd.read_csv(file_bytes)

if uploaded_file:
	try:
		raw_df = cache_csv(uploaded_file)
		temp_path = 'data/_temp.csv'
		raw_df.to_csv(temp_path, index=False)
		data, period = load_csv(temp_path)
		st.success(f'数据加载成功，共 {len(data)} 行，周期: {period}')
	except Exception as e:
		st.error(f'数据加载失败: {e}')
		data = None
else:
	data = None

balance_df = None
trades_df = None
metrics = None

if data is not None and strategy_name and run_btn:
	func, module = load_strategy(os.path.join('strategies', strategy_name))
	if func is None:
		st.error('未找到 strategy 函数')
	else:
		if func.__doc__:
			with st.expander('策略说明 / Docstring'):
				st.code(func.__doc__)
		def strategy_with_hist(row, position):
			i = row.name
			hist = data.iloc[max(0, i-hist_window): i]
			try:
				return func(row, position, hist=hist)
			except TypeError:
				return func(row, position)
		engine = BacktestEngine(
			data,
			strategy_with_hist,
			init_cash=init_cash,
			commission_rate=commission_rate,
			stamp_duty=stamp_duty,
			slippage=slippage,
			exec_price=exec_price,
			max_drawdown_stop=drawdown_stop if drawdown_stop>0 else None,
			max_loss_stop=loss_stop if loss_stop>0 else None,
		)
		with st.spinner('运行回测...'):
			balance_df, trades_df = engine.run()
		if 'equity' not in balance_df.columns and 'total' in balance_df.columns:
			balance_df['equity'] = balance_df['total']
		metrics = calc_metrics(balance_df, trades_df, init_cash=init_cash, period=period)

if balance_df is not None:
	tab_metrics, tab_chart, tab_table = st.tabs(['指标概览','交互图表','交易明细'])
	with tab_metrics:
		st.subheader('回测指标')
		st.table(metrics)
		csv_equity = balance_df[['datetime','equity']].to_csv(index=False).encode('utf-8-sig')
		st.download_button('下载权益曲线CSV', data=csv_equity, file_name='local_equity.csv', mime='text/csv')
	with tab_chart:
		st.subheader('交互图表 (悬停显示)')
		if PLOTLY_AVAILABLE:
			fig = equity_figure(balance_df, trades_df if show_trades else None, show_position=show_position)
			st.plotly_chart(fig, use_container_width=True)
			with st.expander('静态图 (Matplotlib 对照)'):
				st.pyplot(plot_equity_curve(balance_df))
				st.pyplot(plot_drawdown(balance_df))
		else:
			st.warning('Plotly 未安装，已自动降级为静态图。')
			st.info(f"当前运行的 Python 解释器: {sys.executable}")
			st.write('请在与上方路径对应的环境中执行以下任一命令安装 Plotly:')
			st.code('python -m pip install plotly', language='bash')
			st.code('python -m pip install -i https://pypi.tuna.tsinghua.edu.cn/simple plotly  # 使用清华镜像(可选)', language='bash')
			st.pyplot(plot_equity_curve(balance_df))
			st.pyplot(plot_drawdown(balance_df))
	with tab_table:
		st.subheader('交易明细')
		st.dataframe(trades_df, use_container_width=True)
		trades_export = trades_df.copy()
		trades_export['strategy_file'] = strategy_name
		trades_bytes = trades_export.to_csv(index=False).encode('utf-8-sig')
		st.download_button('下载交易明细CSV', data=trades_bytes, file_name=f'trades_{strategy_name}.csv', mime='text/csv')
else:
	st.info('请在左侧上传数据并配置参数后点击 开始回测')
