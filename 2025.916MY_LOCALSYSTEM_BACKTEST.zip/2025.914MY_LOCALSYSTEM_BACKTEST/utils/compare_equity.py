"""对比本地回测与聚宽回测的权益/收益曲线差异

使用方法（示例）：
    python compare_equity.py --local local_equity.csv --jq jq_equity.csv --date-col date --local-col equity --jq-col equity

要求：
- 两个CSV 至少包含日期列与权益(或净值)列
- 日期列可为 'date' 或 'datetime'，自动尝试解析

输出：
- 统一对齐后的统计：
    样本天数、匹配天数
    日收益差异均值、日收益差异标准差
    净值绝对差最大/平均
    相关系数
    是否通过（基于阈值）

阈值默认：
    日收益均值绝对差 < 1e-6 (浮点微小差)
    净值平均差 < 0.001 (0.1%)
    相关系数 > 0.999

可根据需要调整。
"""
import argparse
import pandas as pd


def load_csv(path, date_col):
    df = pd.read_csv(path)
    # 自动识别日期列
    if date_col and date_col in df.columns:
        dcol = date_col
    else:
        candidates = [c for c in ['date', 'datetime', 'time'] if c in df.columns]
        if not candidates:
            raise ValueError('无法找到日期列, 请使用 --date-col 指定')
        dcol = candidates[0]
    df[dcol] = pd.to_datetime(df[dcol])
    df = df.sort_values(dcol)
    return df, dcol


def compute_daily_return(series):
    return series.pct_change().fillna(0.0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--local', required=True, help='本地回测导出的权益CSV')
    parser.add_argument('--jq', required=True, help='聚宽导出的权益CSV')
    parser.add_argument('--date-col', help='日期列名（若省略将自动猜测）')
    parser.add_argument('--local-col', default='equity', help='本地CSV中权益列名')
    parser.add_argument('--jq-col', default='equity', help='聚宽CSV中权益列名')
    parser.add_argument('--mean-ret-diff', type=float, default=1e-6, help='日收益均值差阈值')
    parser.add_argument('--avg-eq-diff', type=float, default=0.001, help='净值平均差阈值 (0.1%)')
    parser.add_argument('--corr-threshold', type=float, default=0.999, help='相关系数阈值')
    args = parser.parse_args()

    local_df, ldate = load_csv(args.local, args.date_col)
    jq_df, jdate = load_csv(args.jq, args.date_col)

    # 重命名统一
    local_df = local_df.rename(columns={ldate: 'date', args.local_col: 'local_equity'})
    jq_df = jq_df.rename(columns={jdate: 'date', args.jq_col: 'jq_equity'})

    merged = pd.merge(local_df[['date', 'local_equity']], jq_df[['date', 'jq_equity']], on='date', how='inner')
    if merged.empty:
        raise ValueError('两个文件日期没有交集')

    merged['local_ret'] = compute_daily_return(merged['local_equity'])
    merged['jq_ret'] = compute_daily_return(merged['jq_equity'])
    merged['ret_diff'] = merged['local_ret'] - merged['jq_ret']
    merged['equity_diff'] = merged['local_equity'] - merged['jq_equity']
    merged['abs_equity_diff'] = merged['equity_diff'].abs()

    stats = {
        'total_local_days': int(local_df.shape[0]),
        'total_jq_days': int(jq_df.shape[0]),
        'matched_days': int(merged.shape[0]),
        'mean_return_diff': float(merged['ret_diff'].mean()),
        'std_return_diff': float(merged['ret_diff'].std()),
        'max_abs_equity_diff': float(merged['abs_equity_diff'].max()),
        'avg_abs_equity_diff': float(merged['abs_equity_diff'].mean()),
        'corr': float(merged[['local_equity', 'jq_equity']].corr().iloc[0,1])
    }

    passed = (
        abs(stats['mean_return_diff']) <= args.mean_ret_diff and
        stats['avg_abs_equity_diff'] <= args.avg_eq_diff and
        stats['corr'] >= args.corr_threshold
    )

    print('=== 对比统计 ===')
    for k,v in stats.items():
        print(f'{k}: {v}')
    print(f'pass: {passed}')

    # 保存详细合并文件方便排查
    merged.to_csv('equity_compare_detail.csv', index=False, encoding='utf-8-sig')
    print('已输出 equity_compare_detail.csv 供进一步检查差异行')

if __name__ == '__main__':
    main()
