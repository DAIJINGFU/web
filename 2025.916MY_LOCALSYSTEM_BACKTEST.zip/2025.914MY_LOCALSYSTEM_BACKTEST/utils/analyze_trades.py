"""交易记录快速分析脚本

用法：
    python utils/analyze_trades.py --trades trades_weekly.csv

功能：
    1. 统计买/卖总次数
    2. weekday 分布（0=周一 ... 6=周日）
    3. 连续同方向次数
    4. 卖出残股(qty=1 或 qty<阈值) 统计
    5. 是否存在首尾方向异常
"""
import argparse
import pandas as pd
import datetime as dt


def parse_dt(x):
    try:
        return pd.to_datetime(x)
    except Exception:
        return dt.datetime.strptime(str(x), '%Y-%m-%d')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--trades', required=True, help='交易CSV')
    ap.add_argument('--small-threshold', type=int, default=1, help='残股阈值(<=该数量计入残股)')
    args = ap.parse_args()

    df = pd.read_csv(args.trades)
    if 'datetime' not in df.columns or 'type' not in df.columns:
        raise ValueError('缺少必要列 datetime/type')
    df['dt'] = df['datetime'].apply(parse_dt)
    df = df.sort_values('dt').reset_index(drop=True)
    df['weekday'] = df['dt'].dt.weekday

    print('=== 基本统计 ===')
    print('总行数:', len(df))
    print('买单数:', (df.type=='buy').sum())
    print('卖单数:', (df.type=='sell').sum())

    print('\n=== Weekday 分布 ===')
    print(df.groupby(['type','weekday']).size())

    # 连续同方向
    repeats = 0
    repeat_indices = []
    last = None
    for i,t in enumerate(df.type):
        if last == t:
            repeats += 1
            repeat_indices.append(i)
        last = t
    print('\n连续同方向次数:', repeats)
    if repeats:
        print('示例索引:', repeat_indices[:10])

    # 残股卖出
    small_sells = df[(df.type=='sell') & (df.qty <= args.small_threshold)] if 'qty' in df.columns else pd.DataFrame()
    if not small_sells.empty:
        print('\n小额卖出(<=阈值)次数:', len(small_sells))
        print(small_sells.head())
    else:
        print('\n无小额卖出')

    # 首尾合理性
    if df.iloc[0].type != 'buy':
        print('警告：首笔不是 buy')
    if df.iloc[-1].type == 'buy':
        print('警告：最后一笔仍是 buy (可能未平仓)')

if __name__ == '__main__':
    main()
