"""验证周一买入周五卖出策略的交易记录正确性

使用方式：
    1. 在前端使用 weekly_mf.py 策略跑完回测，复制交易明细 DataFrame 保存成 trades_weekly.csv
    2. 运行：
        python utils/validate_weekly_strategy.py --trades trades_weekly.csv --data data/你的CSV文件名.csv

检查：
    - buy 必为周一 (weekday==0)
    - sell 必为周五 (weekday==4) 或 最后一笔且 final_close 标记
    - 买卖方向交替
    - 首笔必须 buy
    - 若末笔仍 buy 视为未平仓（提示），若出现 final_close 非最后一笔提示

输出：
    - 通过：打印通过信息
    - 不通过：生成 mismatch_log.csv 记录异常
"""
import argparse
import pandas as pd
import datetime as dt

def parse_dt(x):
    if isinstance(x, dt.datetime):
        return x
    for fmt in ('%Y-%m-%d', '%Y-%m-%d %H:%M:%S', '%Y/%m/%d', '%Y-%m-%d %H:%M:%S%z'):
        try:
            return dt.datetime.strptime(str(x), fmt)
        except Exception:
            continue
    try:
        return dt.datetime.fromisoformat(str(x))
    except Exception:
        raise ValueError(f'无法解析日期: {x}')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--trades', required=True, help='交易记录CSV')
    ap.add_argument('--data', required=False, help='原始行情CSV (用于检查最后交易日)')
    args = ap.parse_args()

    trades = pd.read_csv(args.trades)
    if 'datetime' not in trades.columns or 'type' not in trades.columns:
        raise ValueError('trades 必须包含 datetime 与 type 列')

    trades['dt'] = trades['datetime'].apply(parse_dt)
    trades = trades.sort_values('dt').reset_index(drop=True)

    mismatches = []
    if trades.empty:
        raise ValueError('交易记录为空，策略未产生任何交易')
    if trades.iloc[0]['type'] != 'buy':
        mismatches.append({'idx':0,'reason':'首笔不是 buy'})

    last_type = None
    for i, row in trades.iterrows():
        t = row['type']
        d = row['dt']
        wd = d.weekday()
        if last_type is not None and t == last_type:
            mismatches.append({'idx':i,'reason':'连续相同方向: '+t})
        if t == 'buy' and wd != 0:
            mismatches.append({'idx':i,'reason':f'buy 不在周一({d.date()})'})
        if t == 'sell' and wd != 4:
            is_last = (i == len(trades)-1)
            final_close = str(row.get('final_close','')).lower() in ('1','true','yes')
            if not (is_last and final_close):
                mismatches.append({'idx':i,'reason':f'sell 不在周五({d.date()}) 且不是最后强平'})
        last_type = t

    if trades.iloc[-1]['type'] == 'buy':
        mismatches.append({'idx':len(trades)-1,'reason':'最后一笔仍为 buy (末周未平仓)'} )

    if 'final_close' in trades.columns:
        fc_rows = trades[trades['final_close'] == True]
        if not fc_rows.empty:
            last_idx = trades.index[-1]
            if fc_rows.index[-1] != last_idx or trades.iloc[-1]['type'] != 'sell':
                mismatches.append({'idx':int(fc_rows.index[-1]), 'reason':'final_close 不是最后一笔 sell'})

    if args.data:
        try:
            data = pd.read_csv(args.data)
            if 'datetime' in data.columns:
                last_dt = parse_dt(data['datetime'].iloc[-1])
                print('行情最后日期:', last_dt.date(), 'weekday=', last_dt.weekday())
        except Exception as e:
            print('读取 data 失败:', e)

    if mismatches:
        mm_df = pd.DataFrame(mismatches)
        mm_df.to_csv('mismatch_log.csv', index=False, encoding='utf-8-sig')
        print('验证未全部通过，详情写入 mismatch_log.csv:')
        print(mm_df)
    else:
        print('验证通过：交易记录符合周一买周五卖模式。')

if __name__ == '__main__':
    main()
