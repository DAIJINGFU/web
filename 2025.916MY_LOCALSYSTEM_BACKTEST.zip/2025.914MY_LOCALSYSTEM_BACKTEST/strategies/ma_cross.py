# 示例策略：简单均线交叉

def ma_cross_strategy(row, position, short_window=5, long_window=20, hist=None):
    """
    简单均线交叉策略：
    - 短期均线上穿长期均线买入
    - 短期均线下穿长期均线卖出
    - 其余持有
    参数：
        row: 当前行数据
        position: 当前持仓
        short_window: 短期均线窗口
        long_window: 长期均线窗口
        hist: 历史DataFrame（含close列）
    返回：1买入，-1卖出，0持有
    """
    if hist is None or len(hist) < long_window:
        return 0
    short_ma = hist['close'].iloc[-short_window:].mean()
    long_ma = hist['close'].iloc[-long_window:].mean()
    if short_ma > long_ma and position == 0:
        return 1
    elif short_ma < long_ma and position > 0:
        return -1
    else:
        return 0
