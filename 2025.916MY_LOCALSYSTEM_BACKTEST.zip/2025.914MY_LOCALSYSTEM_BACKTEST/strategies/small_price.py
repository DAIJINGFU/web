"""small_price 策略（基于 JoinQuant 示例的简化单标的版本）

原版逻辑：
  - 在所有市值 20~30 亿之间的股票里选出市值最小的 3 只，等权买入，持有 5 个交易日，之后调仓。

当前项目限制：
  - 现有回测引擎 BacktestEngine 仅支持单一标的、全仓买入/全仓卖出，不支持多股票组合、也没有市值（fundamental）数据。
  - 因此这里给出一个“节奏近似”的单标的简化策略：
      每隔 refresh_rate 天（默认 5 天）满仓买入，持有 hold_days 天（默认 5 天）后卖出，循环往复。
  - 你后续如果扩展成多标的 + 基本面数据（市值），可以再把真正的选股 + 组合调仓逻辑接入。

使用方法：
  在 app.py 里选择此策略文件（small_price.py），系统会自动找到 small_price_strategy 这个函数。

扩展提示：
  - 如果你想把“满仓买入”改成“半仓”或加仓/减仓，需要改引擎支持部分仓位。
  - 如果想真的按市值筛选，需要：
      1) 准备一份市值数据（CSV），或在每只股票的 DataFrame 中增加 market_cap 列。
      2) 改造引擎以支持多个 symbol 的持仓字典。

"""

def create_small_price_strategy(hold_days: int = 5, refresh_rate: int = 5):
    """生成一个可被引擎调用的策略函数。

    参数:
        hold_days: 持有天数（买入后连续持有多少根 K 线/天）
        refresh_rate: 调仓频率（每隔多少根 K 线尝试开仓）

    返回:
        strategy(row, position, hist=None) -> 信号(-1/0/1)
    """
    state = {
        'day_counter': 0,      # 记录走过的 K 线数量，用来判断是否到达调仓点
        'holding_counter': 0,  # 当前持仓已经持有了多少天
        'in_cycle': False      # 是否处于一个持有周期中
    }

    def strategy(row, position, hist=None):
        # 每次调用代表来了一根新的 K 线
        # 先递增 day_counter（或者在逻辑后递增都可以，这里放前面更直观）
        # 但注意：只有真正处理完当前逻辑再递增，避免偏移。
        # 我们选择在逻辑结束前再统一递增。

        signal = 0  # 默认不操作

        if position == 0:
            # 当前空仓，判断是否到达调仓点
            if state['day_counter'] % refresh_rate == 0:
                # 到达调仓点 -> 开始一个新的持有周期
                signal = 1  # 全仓买入
                state['holding_counter'] = 0
                state['in_cycle'] = True
        else:
            # 有持仓，处于持有阶段
            state['holding_counter'] += 1
            # 如果达到预设持有天数，卖出
            if state['holding_counter'] >= hold_days:
                signal = -1  # 全部卖出
                state['in_cycle'] = False

        # 走完当前 K 线，计数+1
        state['day_counter'] += 1
        return signal

    return strategy

# 为了与现有框架的自动发现机制兼容（寻找 *strategy 结尾的函数名），
# 这里提供一个已经实例化好的默认策略函数 small_price_strategy。
# 你也可以在策略目录复制这个文件改参数，再起不同名字。
small_price_strategy = create_small_price_strategy(hold_days=5, refresh_rate=5)
