"""周一买入，周五卖出 验证型策略

用途：用于验证回测引擎撮合与日期循环逻辑是否正确。
规则：
- 周一(weekday==0) 如果当前空仓 -> 全仓买
- 周五(weekday==4) 如果当前有仓 -> 全部卖
- 其余日期保持持仓不变（不操作）
返回信号：1 买入；-1 卖出；0 保持
说明：不使用未来数据；不依赖 hist。

可通过导出的交易明细检查：
1. 所有买单日期都是周一；所有卖单日期都是周五
2. 买卖严格交替；不存在连续买或连续卖
3. 最后一周如果没有周五（数据未到周五），持仓应在回测结束后被强制平仓（final_close 标记）
"""

import datetime as _dt

def weekly_mf_strategy(row, position, hist=None):
    # 假设 row['datetime'] 是可解析的日期时间或字符串
    dt = row['datetime']
    if isinstance(dt, str):
        try:
            dt = _dt.datetime.fromisoformat(dt)
        except Exception:
            dt = _dt.datetime.strptime(dt, '%Y-%m-%d')  # 兜底
    wd = dt.weekday()  # 0=周一 ... 4=周五

    if wd == 0 and position == 0:
        return 1   # 周一开仓
    if wd == 4 and position > 0:
        return -1  # 周五平仓
    return 0

strategy = weekly_mf_strategy
