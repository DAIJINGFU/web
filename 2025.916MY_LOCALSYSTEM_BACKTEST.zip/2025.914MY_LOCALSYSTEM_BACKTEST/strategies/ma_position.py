"""目标仓位版本的均线策略 (不使用未来数据)

逻辑：
- 使用上一根K线（即 hist 的最后一行，不含当前 row）的收盘价计算短/长均线
- 当短均线 > 长均线：目标仓位 100% (1.0)
- 当短均线 < 长均线：目标仓位 0% (0.0)
- 若均线相等保持原仓位（返回当前 position 比例）

注意：引擎会识别返回 {'target_pos': x} 的字典，执行部分仓位调整。

参数：
    row: 当前行（本K线）
    position: 当前持仓股数（引擎内部是绝对数量，这里只用是否>0 决定当前仓位比例表示）
    hist: 历史 DataFrame（不含当前 row 的所有已过去K线），需包含 close 列
    short_window: 短期均线窗口
    long_window: 长期均线窗口
返回：
    dict: {'target_pos': 比例 0~1}
"""

def ma_position_strategy(row, position, hist=None, short_window=5, long_window=20):
    # 没有足够历史，维持空仓
    if hist is None or len(hist) < long_window:
        return {'target_pos': 0.0}

    # 为避免未来函数：均线仅用 hist （已过去）
    closes = hist['close']
    short_ma = closes.iloc[-short_window:].mean()
    long_ma = closes.iloc[-long_window:].mean()

    if short_ma > long_ma:
        return {'target_pos': 1.0}
    elif short_ma < long_ma:
        return {'target_pos': 0.0}
    else:
        # 均线相等，保持当前：>0 视作满仓，否则空仓
        return {'target_pos': 1.0 if position > 0 else 0.0}

# 便于在 app.py 动态加载
strategy = ma_position_strategy
