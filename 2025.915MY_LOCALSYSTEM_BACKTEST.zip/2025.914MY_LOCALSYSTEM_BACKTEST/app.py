# Streamlit 网页入口
import streamlit as st
import pandas as pd
import importlib.util
import os
from backtest.data_loader import load_csv
from backtest.engine import BacktestEngine
from backtest.metrics import calc_metrics
from visualization.plot import plot_equity_curve, plot_drawdown

st.title('本地回测系统')
st.write('请上传行情csv文件，选择策略，开始回测！')

# 上传csv
uploaded_file = st.file_uploader('上传行情csv文件', type=['csv'])
if uploaded_file:
	df = pd.read_csv(uploaded_file)
	# 临时保存
	temp_path = 'data/_temp.csv'
	df.to_csv(temp_path, index=False)
	st.success('数据上传成功！')
	# 策略选择
	strategy_files = [f for f in os.listdir('strategies') if f.endswith('.py')]
	strategy_name = st.selectbox('选择策略', strategy_files)
	# 加载策略
	if strategy_name:
		spec = importlib.util.spec_from_file_location('user_strategy', os.path.join('strategies', strategy_name))
		user_strategy = importlib.util.module_from_spec(spec)
		spec.loader.exec_module(user_strategy)
		# 检查策略函数
		func = None
		for attr in dir(user_strategy):
			if attr.endswith('strategy'):
				func = getattr(user_strategy, attr)
				break
		if func:
			st.write(f'已加载策略: {attr}')
			# 回测参数
			init_cash = st.number_input('初始资金', value=100000)
			if st.button('开始回测'):
				# 数据标准化
				data, period = load_csv(temp_path)
				# 支持历史数据窗口
				def strategy_with_hist(row, position):
					idx = data.index[data['datetime'] == row['datetime']][0]
					hist = data.iloc[max(0, idx-50):idx+1]  # 取近50条历史
					try:
						return func(row, position, hist=hist)
					except TypeError:
						return func(row, position)
				engine = BacktestEngine(data, strategy_with_hist, init_cash=init_cash)
				balance_df, trades_df = engine.run()
				metrics = calc_metrics(balance_df, trades_df, init_cash=init_cash, period=period)
				st.subheader('回测指标')
				st.table(metrics)
				st.subheader('资金曲线')
				fig1 = plot_equity_curve(balance_df, title='资金曲线')
				st.pyplot(fig1)
				st.subheader('最大回撤')
				fig2 = plot_drawdown(balance_df, title='最大回撤')
				st.pyplot(fig2)
				st.subheader('交易明细')
				st.dataframe(trades_df)
		else:
			st.error('策略文件未找到有效的strategy函数')
