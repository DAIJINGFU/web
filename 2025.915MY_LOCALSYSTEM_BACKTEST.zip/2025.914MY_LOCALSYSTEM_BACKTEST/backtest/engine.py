# 回测主引擎
import pandas as pd

class BacktestEngine:
	def __init__(self, data: pd.DataFrame, strategy_func, init_cash=100000):
		self.data = data.copy()
		self.strategy_func = strategy_func
		self.init_cash = init_cash
		self.cash = init_cash
		self.position = 0
		self.trades = []  # 记录每笔交易
		self.daily_balance = []  # 资金曲线

	def run(self):
		for i, row in self.data.iterrows():
			signal = self.strategy_func(row, self.position)
			price = row['close']
			# 简单买卖逻辑：1买入，-1卖出，0持有
			if signal == 1 and self.cash >= price:
				# 全仓买入
				qty = int(self.cash // price)
				if qty > 0:
					self.cash -= qty * price
					self.position += qty
					self.trades.append({'datetime': row['datetime'], 'type': 'buy', 'price': price, 'qty': qty})
			elif signal == -1 and self.position > 0:
				# 全部卖出
				self.cash += self.position * price
				self.trades.append({'datetime': row['datetime'], 'type': 'sell', 'price': price, 'qty': self.position})
				self.position = 0
			# 记录每日资金
			total = self.cash + self.position * price
			self.daily_balance.append({'datetime': row['datetime'], 'total': total, 'cash': self.cash, 'position': self.position})
		# 最后强制平仓
		if self.position > 0:
			price = self.data.iloc[-1]['close']
			self.cash += self.position * price
			self.trades.append({'datetime': self.data.iloc[-1]['datetime'], 'type': 'sell', 'price': price, 'qty': self.position})
			self.position = 0
			self.daily_balance.append({'datetime': self.data.iloc[-1]['datetime'], 'total': self.cash, 'cash': self.cash, 'position': 0})
		return pd.DataFrame(self.daily_balance), pd.DataFrame(self.trades)
